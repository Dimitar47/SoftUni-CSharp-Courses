﻿
using _07.MilitaryElite.Core.Interfaces;
using _07.MilitaryElite.Core;

IEngine engine = new Engine();
engine.Run();