﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomStack5
{
    class StackOfStrings : System.Collections.Stack
    {
        public bool IsEmpty()
        {
            if (Count == 0)
            {
                return true;
            }
            return false;
        }

        public void AddRange(IEnumerable<string> elements)
        {
            foreach (var item in elements)
            {
                Push(item);
            }
        }
    }
}
