﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person1 = new Person() { Age= 20,Name = "Peter" };
            Person person2 = new Person() { Age= 18,Name = "George" };
            Person person3 = new Person() { Age= 43,Name = "Jose" };
            Console.WriteLine(person1.Name);
            Console.WriteLine(person1.Age);

        }
    }
}
