﻿namespace EvenLines
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class EvenLines
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\text.txt";

            Console.WriteLine(string.Join("",ProcessLines(inputFilePath)));
        }

        public static List<string> ProcessLines(string inputFilePath)
        {
            using (StreamReader stream = new StreamReader(inputFilePath))
            {
                int row = 0;
                List<string> splitted = new List<string>();
                List<string> reversed = new List<string>();
                while(!stream.EndOfStream)
                {
                    string currentRow = stream.ReadLine();
                    if (row%2==0)
                    {
                        
                        for (int i = 0; i < currentRow.Length; i++)
                        {
                            // {'-', ', ', '. ', '! ', '? '} 
                            if (currentRow[i] == '-' || currentRow[i] == ','
                                || currentRow[i] == '.' || currentRow[i] == '!'
                                || currentRow[i] == '?')
                            {
                                currentRow = currentRow.Replace(currentRow[i], '@');
                                
                            }
                        }

                         splitted = currentRow.Split(" ",StringSplitOptions.RemoveEmptyEntries).ToList();
                       
                        for (int i = splitted.Count - 1; i >= 0; i--)
                        {
                            reversed.Add(splitted[i] + " ");
                        }
                        reversed.Add("\n");

                    }
                    row++;
                }
              
                return reversed.ToList();
                
            }
        }
    }
}
